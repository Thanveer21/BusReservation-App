package com.example.thanveer.safari;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;
import android.widget.Toast;

public class Profile extends AppCompatActivity {
   /* TextView t1,t2;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile);
        /*Intent i=getIntent();
        t1=(TextView)findViewById(R.id.textView5);
        t1=(TextView)findViewById(R.id.textView6);
        SqliteHelper db=new SqliteHelper(this);
        Cursor cursor = db.alldata();
        if(cursor.getCount() ==0)
        {
            Toast.makeText(getApplicationContext(),"No DATA",Toast.LENGTH_LONG).show();
        }
        else{
            while(cursor.moveToNext()){
                String str=cursor.getString(0);
                String str2=cursor.getString(1);
                t1.setText(str);
                t2.setText(str2);
            }
        }}*/

}
